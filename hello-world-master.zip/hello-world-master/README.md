# maven-project

Simple Maven Project to test using Jenkins
